let navbar=document.getElementById("navBar");

function togglebtn(){
    navbar.classList.toggle("hideMenu");
}